SELECT
    MONTH(p.FechaDeInternacion) AS Mes,
    (
    SELECT
        cs.Nombre
    FROM
        centrosanitario cs
    WHERE
        p.CENTROSANITARIO_id = cs.id
) AS Centro,
SUM(dt.TRIAGECOLOR_id = 1) AS ROJO,
SUM(dt.TRIAGECOLOR_id = 2) AS NARANJA,
SUM(dt.TRIAGECOLOR_id = 3) AS AMARILLO,
SUM(dt.TRIAGECOLOR_id = 4) AS VERDE,
SUM(dt.TRIAGECOLOR_id = 5) AS AZUL
FROM
    diagtriage dt
INNER JOIN paciente p ON
    dt.PACIENTE_id = p.idPACIENTE
GROUP BY
    p.CENTROSANITARIO_id,
    Mes
ORDER BY
    `Centro`, Mes ASC