﻿SELECT
    (
        (
        SELECT
            p.NombreYApellido
        FROM
            persona p
        WHERE
            (p.DNI = e.PERSONA_DNI)
    )
    ) AS "Nombre Enfermero",
    CAST(ehcf.entrada AS DATE) AS "YYYY/MM/DD"
FROM
    (
        empleado_has_centrofichado ehcf
    JOIN empleado e ON
        (
            (ehcf.EMPLEADO_id = e.matricula)
        )
    )
WHERE
    CAST(ehcf.entrada AS DATE) IN(
    SELECT
        CAST(
            viewdiamayormuertos.Fecha AS DATE
        )
    FROM
        viewdiamayormuertos
)