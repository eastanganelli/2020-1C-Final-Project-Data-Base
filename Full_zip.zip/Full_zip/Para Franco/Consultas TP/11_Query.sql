SELECT
    s.FechaYHora AS FechaMuerte,
    p.NombreYApellido AS Paciente,
    cs.Nombre AS Centro,
    vecsf.NombreYApellido AS NombreEmpleado
FROM
    salidas s
INNER JOIN paciente ON s.PACIENTE_id = paciente.idPACIENTE
INNER JOIN persona p ON
    paciente.PERSONA_DNI = p.DNI
INNER JOIN viewempleadocsfichado vecsf ON
    paciente.CENTROSANITARIO_id = vecsf.CENTRO_id
JOIN centrosanitario cs ON
    paciente.CENTROSANITARIO_id = cs.id
WHERE
    s.Estado = 1 AND s.FechaYHora BETWEEN vecsf.entrada AND vecsf.salida