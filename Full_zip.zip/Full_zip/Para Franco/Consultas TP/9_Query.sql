SELECT
    vccc.CENTRO_NOMBRE AS Centro,
    vccc.SemanaControl AS NroSemana,
    (
        (
        SELECT
            COUNT(vcaux.SemanaControl)
        FROM
            viewcentroempchcovid vcaux
        WHERE
            vccc.CENTRO_ID = vcaux.CENTRO_ID AND vccc.SemanaControl = vcaux.SemanaControl AND vcaux.COVID_RES = 1
    )
    ) AS COVIDpositivos,
    (
        (
        SELECT
            COUNT(vcaux.COVID_RES)
        FROM
            viewcentroempchcovid vcaux
        WHERE
            vccc.CENTRO_ID = vcaux.CENTRO_ID AND vccc.SemanaControl = vcaux.SemanaControl
    )
    ) AS 'CantChecks'
FROM
    viewcentroempchcovid vccc,
    centrosanitario cs
WHERE
    (
    SELECT
        COUNT(vcaux.COVID_RES)
    FROM
        viewcentroempchcovid vcaux
    WHERE
        vccc.CENTRO_ID = vcaux.CENTRO_ID AND vccc.SemanaControl = vcaux.SemanaControl
) > 0
GROUP BY
    vccc.SemanaControl,
    vccc.CENTRO_ID
ORDER BY
    vccc.CENTRO_ID,
    vccc.SemanaControl