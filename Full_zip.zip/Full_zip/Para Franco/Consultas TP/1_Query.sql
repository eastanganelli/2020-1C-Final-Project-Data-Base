SELECT
    vpr.Mes AS Mes,
    (
        vpco.CantidadACTIVOS + vpr.Cantidad_de_Recuperados + vpm.Cantidad_de_Muertes
    ) AS Infectados,
    vpco.CantidadACTIVOS AS Activos,
    vpr.Cantidad_de_Recuperados AS Recuperados,
    vpm.Cantidad_de_Muertes AS Muertos,
    vpr.Provincia AS Zona
FROM
    viewpacrecup vpr
INNER JOIN viewpacmuertos vpm ON
    vpr.Provincia = vpm.Provincia AND vpr.Mes = vpm.Mes
INNER JOIN viewpaccovid vpco ON
    vpr.Provincia = vpco.Provincia AND vpr.Mes = vpco.Mes
WHERE
    vpr.Provincia = "Ciudad Autónoma de Buenos Aires"