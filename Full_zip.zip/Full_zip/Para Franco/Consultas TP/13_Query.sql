SELECT
    MONTH(p.FechaDeInternacion) AS Mes,
    cs.Nombre AS CentroNombre,
    SUM(
        cshe.funcion_id = vfl.id AND vfl.lugar = 'Unidad de Tratamientos Intensivos'
    ) AS CANT_Internados,
    SUM(p.CovidTest=1) AS COVID_POS,
    (SUM(
        cshe.funcion_id = vfl.id AND vfl.lugar = 'Unidad de Tratamientos Intensivos'
    )-SUM(p.CovidTest=1)) AS COVID_NEG
FROM
    centrosanitario_has_empleado cshe
    JOIN viewfuncionylugar vfl ON
        cshe.funcion_id = vfl.id AND vfl.lugar = 'Unidad de Tratamientos Intensivos'
    JOIN centrosanitario cs ON
        cshe.centro_id = cs.id
        JOIN empleado e ON cshe.matricula_id=e.matricula
        JOIN paciente p ON e.PERSONA_DNI=p.PERSONA_DNI
GROUP BY
    CentroNombre
ORDER BY
  CentroNombre,
    Mes