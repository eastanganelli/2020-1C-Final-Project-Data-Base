SELECT
    MONTH(p.FechaDeInternacion) AS Mes,
    cs.Nombre AS Centro,
    SUM(
        p.CovidTest = 1 AND tpi.Respirador = 0
    ) AS CantidadSinRespiCOVID,
    SUM(
        p.CovidTest = 0 AND tpi.Respirador = 0
    ) AS CantidadSinRespiNoCOVID,
    SUM(
        p.CovidTest = 1 AND tpi.Respirador = 1
    ) AS CantidadRespiCOVID,
    SUM(
        p.CovidTest = 0 AND tpi.Respirador = 1
    ) AS CantidadRespiNoCOVID
FROM
    terapiaintensiva tpi
INNER JOIN paciente p ON
    tpi.PACIENTE_id = p.idPACIENTE
    JOIN centrosanitario cs ON p.CENTROSANITARIO_id=cs.id
GROUP BY
    p.CENTROSANITARIO_id,
    Mes
ORDER BY
    Mes,
    `Centro` ASC