SELECT
    fecovid.DNI_Empleado AS "DNI_Empleado",
    (
    SELECT
        p.NombreYApellido
    FROM
        persona p
    WHERE
        p.DNI = fecovid.DNI_Empleado
) AS "Empleado Nombre",
fecovid.DNIFamiliar AS "DNI2Check",
fecovid.NomFamiliar AS "Persona2Check",
"FAMILIAR" AS "Relacion"
FROM
    viewfamiliaresempacheck fecovid
WHERE
    fecovid.DNIFamiliar IS NOT NULL AND fecovid.NomFamiliar IS NOT NULL AND fecovid.DNI_Empleado IS NOT NULL
UNION
SELECT
    etobc.EmpleadoCOVIDDNI AS "DNI_Empleado",
    (
    SELECT
        p.NombreYApellido
    FROM
        persona p
    WHERE
        p.DNI = etobc.EmpleadoCOVIDDNI
) AS "Empleado Nombre",
etobc.Empleado2CheckDNI AS "DNI2Check",
etobc.Empleado2Check AS "Persona2Check",
"COMPAÑERO TRABAJO" AS "Relacion"
FROM
    viewempleadosasercheck etobc
WHERE
    etobc.Empleado2CheckDNI IS NOT NULL AND etobc.Empleado2Check IS NOT NULL AND etobc.EmpleadoCOVIDDNI IS NOT NULL