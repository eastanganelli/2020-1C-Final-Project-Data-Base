SELECT
    (
        (
        SELECT
            p.NombreYApellido
        FROM
            persona p
        WHERE
            p.DNI = paciente.PERSONA_DNI
    )
    ) AS `PacienteNombre`,
    salidas.FechaYHora AS `fecha salida`,
    paciente.FechaDeInternacion AS `fecha entrada`,
    IF(
        TO_DAYS(
            CAST(salidas.FechaYHora AS DATE)
        ) - TO_DAYS(
            CAST(
                paciente.FechaDeInternacion AS DATE
            )
        ) > 0,
        TO_DAYS(
            CAST(salidas.FechaYHora AS DATE)
        ) - TO_DAYS(
            CAST(
                paciente.FechaDeInternacion AS DATE
            )
        ),
        (
            TO_DAYS(
                CAST(salidas.FechaYHora AS DATE)
            ) - TO_DAYS(
                CAST(
                    paciente.FechaDeInternacion AS DATE
                )
            )
        ) *(-1)
    ) AS `Tiempo de Recuperación (Días)`
FROM
    salidas
INNER JOIN paciente ON salidas.PACIENTE_id = paciente.idPACIENTE
WHERE
    salidas.Estado = 2 AND paciente.CovidTest = 1
ORDER BY
    salidas.PACIENTE_id