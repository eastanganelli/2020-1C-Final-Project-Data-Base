SELECT
    cs.id,
    cs.Nombre AS "Centrosanitario",
    (
    SELECT
        prov.Provincia
    FROM
        provincia prov
    WHERE
        `prov`.`idPROVINCIA` = cs.PROVINCIA_idPROVINCIA
) AS "Pronvicia",
IF(
    (
    SELECT
        csfm.avgRecuperados
    FROM
        viewcsfemavgrede csfm
    WHERE
        csfm.idCS = cs.id
) IS NULL,
"NO HAY DATOS",
(
    SELECT
        csfm.avgRecuperados
    FROM
        viewcsfemavgrede csfm
    WHERE
        csfm.idCS = cs.id
)
) AS "AVGMujRecup",
IF(
    (
    SELECT
        csfm.avgRecuperados
    FROM
        viewcsfemavgrede csfm
    WHERE
        csfm.idCS = cs.id
) IS NULL,
"NO HAY DATOS",
(
    SELECT
        csfm.avgMuertos
    FROM
        viewcsfemavgrede csfm
    WHERE
        csfm.idCS = cs.id
)
) AS "AVGMujMuertas",
IF(
    (
    SELECT
        csfm.avgRecuperados
    FROM
        viewcsmasavgrede csfm
    WHERE
        csfm.idCS = cs.id
    GROUP BY
        csfm.idCS
) IS NULL,
"NO HAY DATOS",
(
    SELECT
        csfm.avgRecuperados
    FROM
        viewcsmasavgrede csfm
    WHERE
        csfm.idCS = cs.id
    GROUP BY
        csfm.idCS
)
) AS "AVGHomRecup",
IF(
    (
    SELECT
        csfm.avgRecuperados
    FROM
        viewcsmasavgrede csfm
    WHERE
        csfm.idCS = cs.id
    GROUP BY
        csfm.idCS
) IS NULL,
"NO HAY DATOS",
(
    SELECT
        csfm.avgMuertos
    FROM
        viewcsmasavgrede csfm
    WHERE
        csfm.idCS = cs.id
    GROUP BY
        csfm.idCS
)
) AS "AVGHomMUERTOSS"
FROM
    centrosanitario cs
GROUP BY
    cs.Nombre  
ORDER BY `Pronvicia` ASC