SELECT
    IF(
        (
            (
                HOUR(ehcf.salida) - HOUR(ehcf.entrada)
            ) < 0
        ),
        (
            -(1) *(
                HOUR(ehcf.salida) - HOUR(ehcf.entrada)
            )
        ),
        (
            HOUR(ehcf.salida) - HOUR(ehcf.entrada)
        )
    ) AS 'Horas Trabajadas',
    (
    SELECT
        persona.DNI
    FROM
        persona
    WHERE
        (
            persona.DNI = empleado.PERSONA_DNI
        )
) AS 'DNI_Empleado',
(
    SELECT
        persona.NombreYApellido
    FROM
        persona
    WHERE
        (
            persona.DNI = empleado.PERSONA_DNI
        )
) AS 'Nombre y Apellido',
cs.nombre AS "Centro Sanitario"
FROM
    (
        empleado_has_centrofichado ehcf
    JOIN empleado ON
        (
            (
                empleado.matricula = ehcf.EMPLEADO_id
            )
        )
    JOIN centrosanitario cs ON
        ehcf.CENTRO_id = cs.id
    )
WHERE
    (
        IF(
            (
                (
                    HOUR(ehcf.salida) - HOUR(ehcf.entrada)
                ) < 0
            ),
            (
                -(1) *(
                    HOUR(ehcf.salida) - HOUR(ehcf.entrada)
                )
            ),
            (
                HOUR(ehcf.salida) - HOUR(ehcf.entrada)
            )
        ) > 0
    )
ORDER BY
    `Horas Trabajadas`
DESC