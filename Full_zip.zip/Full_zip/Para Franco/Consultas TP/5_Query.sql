SELECT
    edm.Med_DNI,
    edm.Med_Nom,
    edm.Med_Matricula,
    sumcar.IngresoID,
    sumcar.CostoUni,
    sumcar.CostoMenor AS "CostoCompared",
    sumcar.Compara AS "IDCompared",
    sumcar.Nombre AS "Nom_Sum",
    psum.nombre AS "Nom_proveedor",
    psum.direccion,
    psum.Provincia,
    psum.email,
    psum.Telefono
FROM
    (
        viewsummascaros sumcar
    JOIN viewproveedorsum psum ON
        psum.INGRESO_id = sumcar.IngresoID
    JOIN viewempnomdnimat edm ON
        sumcar.EmpID = edm.EmpID
    )
GROUP BY
    sumcar.Nombre