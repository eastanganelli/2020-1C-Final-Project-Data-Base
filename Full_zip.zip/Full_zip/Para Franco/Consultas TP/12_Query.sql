SELECT
    s.nombre AS 'Suministro',
    s.cantidad AS 'Cantidad Debajo de 10',
    slp.tipoPeti AS 'Lvl Peticion Sum', ##Nivel de petición que posee ese suministro
    IF(
        s.cantidad >= 6 AND slp.id <= 2,
        'Baja',
        IF(
            s.cantidad < 6 AND slp.id >= 3,
            'Crtica',
            'Media'
        )
    ) AS 'Urgencia de STOCK' ##Urgencia para pedir más
FROM
    suministro s
INNER JOIN suministro_lvlpeticion slp ON
    s.nivel_peticion = slp.id
WHERE
    s.cantidad < 10  
ORDER BY s.nivel_peticion  DESC ##Se ordena por Peticion Suministro