SELECT
    (
    SELECT
        s.nombre
    FROM
        suministro s
    WHERE
        s.FARMACEUTICA_id = mt.FARMACEUTICA_id
) AS 'Medicamento',
COUNT(mt.FARMACEUTICA_id) AS 'CantidadSum'
FROM
    medtratamiento mt
INNER JOIN salidas s ON
    mt.PACIENTE_id = s.PACIENTE_id AND s.Estado = 2
GROUP BY
    mt.FARMACEUTICA_id
ORDER BY
    `CantidadSum`
DESC