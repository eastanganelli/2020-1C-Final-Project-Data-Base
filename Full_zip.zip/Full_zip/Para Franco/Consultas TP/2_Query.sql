SELECT
    (
    SELECT
        e.Nombre
    FROM
        enfermedad e
    WHERE
        e.idEnfermedad = pe.ENFERMEDAD_id
) AS 'NomEnfermedad',
COUNT(pe.ENFERMEDAD_id) AS 'CantidadMuertos'
FROM
    paciente_enfermedades pe
INNER JOIN salidas s ON
    pe.PACIENTE_id = s.PACIENTE_id AND s.Estado = 1
WHERE
    'NomEnfermedad' IS NOT NULL
GROUP BY
    pe.ENFERMEDAD_id