SELECT
    MONTH(p.FechaDeInternacion) AS Mes,
    cs.Nombre AS CentroNombre,
    SUM(s.Estado = 1) AS MuertosCOVID,
    SUM(s.Estado = 2) AS RecupCOVID,
    (
        SUM(s.Estado = 1) + SUM(s.Estado = 2)
    ) AS "TotalCOVID"
FROM
    centrosanitario_has_empleado cshe
JOIN centrosanitario cs ON
    cshe.centro_id = cs.id
JOIN empleado e ON
    cshe.matricula_id = e.matricula
JOIN paciente p ON
    e.PERSONA_DNI = p.PERSONA_DNI
JOIN salidas s ON
    p.idPACIENTE = s.PACIENTE_id
GROUP BY
    CentroNombre
ORDER BY
    CentroNombre,
    Mes