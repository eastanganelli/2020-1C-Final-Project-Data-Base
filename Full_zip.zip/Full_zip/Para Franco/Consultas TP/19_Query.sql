SELECT
    pp.NombreYApellido AS NomPaciente,
    salidas.PACIENTE_id AS `Historial paciente`,
    (COUNT(`salidas`.`PACIENTE_id`) - 1) AS `Nro Reincidencias`,
    COUNT(`salidas`.`PACIENTE_id`) AS `Nro Salidas`
FROM
    `salidas`
INNER JOIN paciente p ON
    salidas.PACIENTE_id = p.idPACIENTE
INNER JOIN persona pp ON
    p.PERSONA_DNI = pp.DNI
WHERE
    (
        (`salidas`.`Estado` = 2) AND `salidas`.`PACIENTE_id` IN(
        SELECT
            `salidas`.`PACIENTE_id`
        FROM
            `salidas`
        WHERE
            (`salidas`.`Estado` = 2)
        GROUP BY
            `salidas`.`PACIENTE_id`
        HAVING
            (COUNT(0) > 1)
    )
    )
GROUP BY
    `salidas`.`PACIENTE_id`
ORDER BY
    `Nro Salidas`
DESC